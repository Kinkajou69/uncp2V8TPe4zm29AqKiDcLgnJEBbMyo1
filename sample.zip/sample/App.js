import React, { useState } from 'react';
import { Text, View, StyleSheet, TextInput, Button } from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  const [name, setName] = useState('Guest user');
  const [age, setAge] = useState('18');
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>;
      Enter your name:</Text>
      <TextInput
        style={styles.input}
        placeholder="eg: John Williams"
        onChangeText={(val) => setName(val)}
      />
      <Text style={styles.paragraph}>Enter your Age:</Text>
      <TextInput style={styles.input} />
      <Text style={styles.container}> Welcome {name}</Text>
      <Button title="Let's get started"> </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    margin: 2,
    padding: 5,
  },
  paragraph: {
    margin: 2,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'center',
    color:'teal', 
  },
  input: {
    borderWidth: 1,
    borderColor: '#777',
    padding: 8,
    textAlign: 'center',
    margin: 50,
    width: 200,
    justifyContent: 'center',
  },
});
