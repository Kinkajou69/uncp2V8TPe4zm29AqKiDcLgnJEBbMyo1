import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  Button,
  TouchableOpacity,
} from 'react-native';
import Constants from 'expo-constants';
import HomeScreen from './HomeScreen';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';

export default function MainPage({navigation}) {
  const [name, setName] = useState('Guest user');
  const [age, setAge] = useState('18');
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Enter your name:</Text>
      <TextInput
        style={styles.input}
        placeholder="eg: John Williams"
        onChangeText={(val) => setName(val)}
      />
      <Text style={styles.paragraph}>Enter your Age:</Text>
      <TextInput style={styles.input} />
      <Text style={styles.container}> Welcome {name}</Text>
      <TouchableOpacity
        style={styles.button}
        onPress={() =>navigation.navigate("HomeScreen")}>
        <Text>Lets Get Started</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    margin: 2,
    padding: 4,
  },
  paragraph: {
    margin: 2,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#777',
    padding: 8,
    textAlign: 'center',
    margin: 50,
    width: 100,
    justifyContent: 'center',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    backgroundColor: 'cyan',
    margin: 10,
    marginLeft: 70,
    width: 200,
    height: 50,
  },
});
