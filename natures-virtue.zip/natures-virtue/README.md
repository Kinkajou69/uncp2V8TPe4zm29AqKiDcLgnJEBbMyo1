YoutubeVideoLink::https://youtu.be/c47Ure48FfQ

# Natures Virtue Mobile app
**Programming environment used**- Expo Snack
Expo Snack is an open-source platform for running React Native apps in the browser. It dynamically bundles and compiles code and runs it in the Expo Client or in a web-player. Code can be saved as "Snacks" and easily shared with others. 

# Steps to run this project:
Visit snack.exp.dev
Under projects, select Import Git repository option from the menu
Paste the git repository url.
Run the app directly on your phone or tablet by clicking the **Run** button or use the simulator by clicking **Tap to Play**. 
You can use physical devices or emulators.
